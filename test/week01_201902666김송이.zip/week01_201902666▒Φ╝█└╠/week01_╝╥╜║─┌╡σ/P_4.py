def main():
    n, k, i = map(int, input().split())
    array = list(map(int, input().split()))
    array.sort()
    k_min = array[k - 1]
    i_max = array[n-i]

    print(abs(i_max - k_min))


if __name__ == '__main__':
    main()
