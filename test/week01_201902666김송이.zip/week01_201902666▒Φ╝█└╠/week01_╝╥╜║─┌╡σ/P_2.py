def main():
    num = int(input())
    array=[]

    for i in range(0,num):
        array.append(input())

    for j in range(0,num):
        print(array[j])


if __name__ == '__main__':
    main()

