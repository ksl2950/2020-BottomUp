def main():
    for i in range(3):
        print('Hello, Algorithm!')


if __name__ == '__main__':
    main()
