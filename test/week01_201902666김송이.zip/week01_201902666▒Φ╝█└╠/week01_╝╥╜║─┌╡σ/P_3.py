def main():
    input_num = int(input())
    if input_num % 3 == 0:
        print('Hello, Coding Test!')
    elif input_num % 4 == 0:
        if input_num % 12 == 0:
            print('Hello, Coding Test!')
        print('2020 Algorithm')
    else:
        for i in range(input_num):
            print('01 Code Test Basic')


if __name__ == '__main__':
    main()
